# apply a threshold to an image

import sys
import skimage.io
import skimage.transform

# read in an image
image = skimage.io.imread(fname=sys.argv[1])

# read in the threshold
threshold = int(sys.argv[2])

# change high intensity pixels to gray
image[image > threshold] = 64

# save out image
skimage.io.imsave(fname='new.png', arr=image)
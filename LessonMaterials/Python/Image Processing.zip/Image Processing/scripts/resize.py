# this is going to be a script to resize images
import sys
import skimage.io
import skimage.transform

print(len(sys.argv), str(sys.argv))

# read in an image
image = skimage.io.imread(fname=sys.argv[1])

# resize the image
new_shape = ((image.shape[0] // 2), image.shape[1] // 2, image.shape[2])
small = skimage.transform.resize(image=image, output_shape=new_shape)

# save out image
skimage.io.imsave(fname='new.jpg', arr=small)
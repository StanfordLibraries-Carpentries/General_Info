"""
* Python script to ignore low intensity pixels in an image.
*
* usage: python HighIntensity.py <filename>
"""
import sys
import skimage.io
import skimage.viewer

# read input image, based on filename parameter
image = skimage.io.imread(fname=sys.argv[1])

threshold = int(sys.argv[2])

image[image < threshold] = 0

# display original image
viewer = skimage.viewer.ImageViewer(image)
viewer.show()